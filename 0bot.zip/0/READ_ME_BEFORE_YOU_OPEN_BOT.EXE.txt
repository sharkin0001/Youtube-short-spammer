Make sure to turn off anti-virus before opening the bot!
This is to prevent it from crashing & get less errors.